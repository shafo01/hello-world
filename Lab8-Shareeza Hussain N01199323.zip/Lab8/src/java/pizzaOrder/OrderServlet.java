/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzaOrder;


import java.sql.*;
import javax.servlet.http.HttpServlet;
import javax.*;
import java.*;
import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.sql.*;
import javax.naming.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author shareeza
 */
public class OrderServlet extends HttpServlet  {
     Connection connection = null;
      private DataSource ds;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet OrderServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet OrderServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
  
 @Override
    public void init() throws ServletException {        
      
       Context ctx; 
         try {
             ctx = new InitialContext();
             ds = (DataSource)ctx.lookup("jdbc/CustomerDatasource"); 
             connection = ds.getConnection();
         } catch (NamingException ex) {
             Logger.getLogger(OrderServlet.class.getName()).log(Level.SEVERE, null, ex);
         } catch (SQLException ex) {
             Logger.getLogger(OrderServlet.class.getName()).log(Level.SEVERE, null, ex);
         }
       

        
        
         }
         
    
  
  
  /*  private Connection getConnection() throws SQLException {
    return ds.getConnection();
  }*/
  
  
  
    
    /*@Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
         try (PrintWriter out = response.getWriter()) {
        //processRequest(request, response);
        
        
        String CustomerName= request.getParameter("customerName");
        String address = request.getParameter("customerAddress");
        String cust_id = request.getParameter("customerID");
        
        String tops = request.getParameter("topping");
        String size = request.getParameter("size");
        
        int ID = Integer.parseInt(cust_id);
        int sz = Integer.parseInt(size);
     
        
        // Class.forName("org.apache.derby.jdbc.ClientDriver").newInstance();
            //Get a connection
         //Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/pizza"); 
        
      
      
     //out.println(connection.toString());
     // String query = "INSERT into APP.CUSTOMERINFO(CUSTOMERID,CUSTOMERNAME,SHIPPINGADDRESS)VALUES ('"+ID+"','"+CustomerName+"','"+address+"');";
    
      Statement stmt = connection.createStatement();
     // Statement stmt1 = connection.createStatement();
      stmt.execute("insert into APP.CUSTOMERINFO values (" +
                    ID + ",'" + CustomerName+ "','" + address +"')");
            
            
     // Order DB
             stmt.execute("insert into APP.ORDERS values (" +
                    ID + "," + sz+ ",'" + tops +"')");
            stmt.close();
     
   
//PreparedStatement insertStatement = connection.prepareStatement("INSERT into APP.CUSTOMERINFO(CUSTOMERID,CUSTOMERNAME,SHIPPINGADDRESS) VALUES (?,?,?)");
        
            //insertStatement.setInt(1,2);  
            // insertStatement.setString(2,CustomerName);  
            //insertStatement.setString(3, address);
             //insertStatement.executeUpdate(); 

      

       
        out.println("value inserted");
       
               
            
   
         } catch (SQLException ex) {
             Logger.getLogger(OrderServlet.class.getName()).log(Level.SEVERE, null, ex);
       
             Logger.getLogger(OrderServlet.class.getName()).log(Level.SEVERE, null, ex);
         }//end printer
        
    }*/

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        response.setContentType("text/html");
        try {
		PrintWriter out = response.getWriter();
        ///out.println(ds.getConnection().toString());
       String error = "";
            String customerID =  request.getParameter("customerID").trim();
            if(customerID== null || "".equals(customerID))
            {
              
                error = error + "You have to enter the customer id <br/>";
              //error this should not be null
              
            }
            else
            {
                int cust_id_length = customerID.length();
                if(cust_id_length == 5)
                {
                    //check if all entered are digits
                  Pattern digit_patterm = Pattern.compile("\\d+");
                  Matcher digit_matcher = digit_patterm.matcher(customerID);
                  boolean matched = digit_matcher.matches();
                    if(matched)
                   {
                    //yaay entered correct Customer ID
                     }
                   else
                    {
                      //error
                        //can only have digits entered
                        error = error + "Customer ID must only have digits <br/>";
                      }
               
                }
                else
                {
                    
                 //error customer id must be 6 digits
                    error = error + "Customer ID must have 5 digits <br/>";
              
                }
                
           
            }
          
          
          //get customer name
          String customerName = request.getParameter("customerName").trim();
          if("".equals(customerName) || customerName == null)
          {
              
          //error
              //customer name must be entered
              error = error + "Please input the customer name <br/>";
          }
          else
          {
              //check to see if customer name has only letters and space
              Pattern name_pattern = Pattern.compile("^[ A-z]+$");
         Matcher matcher = name_pattern.matcher(customerName);
      boolean matched = matcher.matches();
      if(matched)
      {
          //condition met 
          //user entered a valid name
      }
      else
      {
          //user entered name in incorrect format
          error = error + "Customer name cannot have number <br/>";
      }
              
          }
          
          String sz =  request.getParameter("size");
          
          if(sz == null || "".equals(sz))
          {
              //size is not selected
              error = error + "Please select size of pizza <br/>";
             
              
          }
          else
          {
             //size selected so condition met
          }
          
          
          String address = request.getParameter("customerAddress");
          
           if(address == null || "".equals(address))
          {
              //size is not selected
              error = error + "Please input address <br/>";
             
              
          }
          
         //get topping
          String[] tops = request.getParameterValues("topping");
          try
          {
          int num_tops = tops.length;
          if(num_tops <1)
          {
              
          //have to enter at least one topping
              error = error + "Please select at least one topping <br/>";
          }
          else
          {
              //condition met; at least one topping was selected
          }
          }
          catch (Exception e)
                  {
                      //instuct user to enter topping
                      error = error + "Please select at least one topping <br/>";
                  
                  }
          
         String top_name="";
        
	 if("".equals(error))
          {
		
		out.println("<html><head><title>Order Confirmation</title></head><body>");
		out.println("Dear " + customerName + "  "  + "your order for a " + sz + " inch pizza with ");
		int i = 0;
          String top_string ="";
                while(i < tops.length)
           {
               
               top_string = tops[i];
               top_name = top_name + top_string;
               
               out.println(top_string);
               if(i < tops.length-1)
               {
                 out.println(" ,");
               }
               i++;
           }
           int ID = Integer.parseInt(customerID);
           int size = Integer.parseInt(sz);
                 Statement stmt = connection.createStatement();
     // Statement stmt1 = connection.createStatement();
      stmt.execute("insert into APP.CUSTOMERINFO values (" +
                    ID + ",'" + customerName+ "','" + address +"')");
            
            
     // Order DB
             stmt.execute("insert into APP.ORDERS values (" +
                    ID + "," + size+ ",'" + top_name +"')");
            stmt.close();
            out.println("Record Inputted");
           
                
		out.println("<br>is on the way!<br>");
		out.println("Click <a href='index.html'>here</a> to order another");
                out.println("<br>");
                out.println("</body></html>");
		out.close();
                
                }
          else{
                    inputError(request, response, error, customerID, customerName, sz, tops);
          }
                
		}
         
	catch(Exception e1)
	{e1.printStackTrace();
        
        }

        
    
        
    }  
    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        
      
        
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
    
    private void inputError(HttpServletRequest req, 
	HttpServletResponse res, String msg, String cust_id, String cust_name, String size,
    String [] tops) {
	try {
		PrintWriter out = res.getWriter();
		res.setContentType("text/html");
		out.println("<html><head><title>Pizza Order</title></head><body>");
		out.println("<font color=red size=10>"+ msg + "</font><p>");

		ServletContext sc = getServletConfig().getServletContext();
                
                req.setAttribute("customerID", cust_id);
                req.setAttribute("customerName", cust_name);
                req.setAttribute("size", size);
                req.setAttribute("topping", tops);
		RequestDispatcher rd = 
			sc.getRequestDispatcher("/index.jsp");
		rd.include(req, res);
                
                
		out.println("</body></html>");
		out.close();
	}
	catch(Exception e1)
	{e1.printStackTrace();	}
    
}
    
   

}